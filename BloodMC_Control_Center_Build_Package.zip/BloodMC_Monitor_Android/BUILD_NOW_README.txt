BloodMC Control Center - Build package

This project contains:
- Android Java app (Minecraft Java status query only; server control is not connected)
- Windows Electron desktop dashboard (demo UI)
- GitHub Actions workflow to build both installable artifacts

BUILD ON GITHUB:
1. Upload/push the contents of this folder to your GitHub repository's main branch.
2. Open the repository -> Actions.
3. Select "Build BloodMC Control Center" -> Run workflow, or wait for the push build.
4. When both jobs finish, download artifacts:
   - BloodMC-Android-APK (app-debug.apk)
   - BloodMC-Windows-Installer (setup .exe)

LOCAL ANDROID BUILD:
Use JDK 17, Android SDK platform 35 and Gradle 8.9:
  gradle assembleDebug

LOCAL WINDOWS BUILD:
Install Node.js 22, then in desktop folder:
  npm install
  npm run dist:win

Important:
- This package does not include a working host-panel/API connection.
- Android app performs Minecraft Java status checks to the addresses currently in MainActivity.java.
- Console, player management, file management and server actions in the desktop dashboard are demonstration UI only.
- Do not place hosting passwords, session cookies, or API tokens in the app.
