# BloodMC Control Center — Windows desktop starter

This is the first desktop UI milestone. It includes a responsive red/black dashboard and navigation for Overview, Servers, Live Console, Players, File Manager, Backups, Plugins and Settings.

## Run on Windows
1. Install Node.js LTS from https://nodejs.org/.
2. Open PowerShell in this `desktop` folder.
3. Run `npm install`.
4. Run `npm start`.

## Build a Windows installer
Run `npm run dist:win`. The installer will be generated in `desktop/dist`.

## Current limitations
The dashboard intentionally shows preview/unknown values. It does not pretend to control a live server. Real start/stop/restart, command execution, files, player moderation and TPS/CPU/RAM require a supported hosting API or a trusted server-side bridge. Never put hosting passwords or API tokens in the desktop renderer or Android app.

The existing Android project is preserved in the parent folder.
