# BloodMC Monitor — Android project

Android app project for a lightweight Minecraft Java status monitor.

## Targets included
- 134.255.255.67:27064
- 134.255.255.67:27222
- 134.255.255.67:27060
- 134.255.255.66:19214

## Build an APK
This environment did not have Android SDK / Gradle installed, so an APK has not
been compiled here. To build on a computer:

1. Install Android Studio (with Android SDK Platform 35).
2. Open this folder as an existing project.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually:
   `app/build/outputs/apk/debug/app-debug.apk`

Or from a terminal with Gradle installed:
```bash
gradle assembleDebug
```

Minimum Android version: Android 6.0 (API 23).

The app sends one Minecraft Java Server List status request per address every
15 seconds. It reports reachability, response time, version, and online/max
players when the server returns status data. It does not read TPS, MSPT, CPU,
or RAM; those require a server-side plugin or hosting panel.

Connection failures can mean the port is closed, the server is offline, the
host filters status requests, or the network timed out. They do not always prove
the Minecraft process itself is stopped.

## Automated APK and Windows installer
A GitHub Actions workflow is included at `.github/workflows/build.yml`.
Push this project to GitHub and run the workflow from the Actions tab. It produces separate APK and Windows EXE artifacts.
See `BUILD_NOW_README.txt` for steps and limitations.
