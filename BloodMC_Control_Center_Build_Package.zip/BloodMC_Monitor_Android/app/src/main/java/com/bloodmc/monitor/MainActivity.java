package com.bloodmc.monitor;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 12, 15);
    private static final int PANEL = Color.rgb(27, 27, 33);
    private static final int RED = Color.rgb(235, 45, 55);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(170, 170, 180);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final List<TextView> cards = new ArrayList<>();
    private TextView updated;
    private boolean stopped = false;

    private static final Target[] TARGETS = new Target[] {
        new Target("134.255.255.67", 27064),
        new Target("134.255.255.67", 27222),
        new Target("134.255.255.67", 27060),
        new Target("134.255.255.66", 19214)
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        refresh();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(20));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("BLOODMC");
        title.setTextColor(RED);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("SERVER MONITOR  •  MINECRAFT JAVA");
        subtitle.setTextColor(MUTED);
        subtitle.setTextSize(11);
        subtitle.setPadding(0, dp(3), 0, dp(18));
        root.addView(subtitle);

        TextView refresh = new TextView(this);
        refresh.setText("تحديث الآن  ↻");
        refresh.setTextColor(WHITE);
        refresh.setTextSize(14);
        refresh.setGravity(Gravity.CENTER);
        refresh.setBackgroundColor(RED);
        refresh.setPadding(dp(12), dp(12), dp(12), dp(12));
        refresh.setOnClickListener(v -> refresh());
        root.addView(refresh, new LinearLayout.LayoutParams(-1, -2));

        updated = new TextView(this);
        updated.setText("جارٍ الاتصال...");
        updated.setTextColor(MUTED);
        updated.setTextSize(12);
        updated.setPadding(0, dp(12), 0, dp(8));
        root.addView(updated);

        for (Target target : TARGETS) {
            TextView card = new TextView(this);
            card.setText(target.host + ":" + target.port + "\nجارٍ الفحص...");
            card.setTextColor(WHITE);
            card.setTextSize(14);
            card.setLineSpacing(dp(5), 1f);
            card.setPadding(dp(15), dp(15), dp(15), dp(15));
            card.setBackgroundColor(PANEL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(7), 0, dp(7));
            root.addView(card, lp);
            cards.add(card);
        }

        TextView foot = new TextView(this);
        foot.setText("فحص حالة خفيف كل 15 ثانية • لا ينفّذ هجمات أو ضغط شبكي");
        foot.setTextColor(MUTED);
        foot.setTextSize(11);
        foot.setPadding(0, dp(15), 0, 0);
        root.addView(foot);
        setContentView(scroll);
    }

    private void refresh() {
        updated.setText("جارٍ فحص السيرفرات...");
        worker.execute(() -> {
            List<Status> results = new ArrayList<>();
            for (Target t : TARGETS) results.add(check(t));
            handler.post(() -> {
                if (stopped) return;
                for (int i = 0; i < results.size(); i++) {
                    Status s = results.get(i);
                    TextView card = cards.get(i);
                    card.setTextColor(s.online ? WHITE : Color.rgb(255, 130, 130));
                    String text = s.target.host + ":" + s.target.port + "\n";
                    if (s.online) {
                        text += "● ONLINE     Ping: " + s.ping + " ms\n";
                        text += "Players: " + s.players + "\n";
                        text += "Version: " + s.version + "\n";
                        text += "MOTD: " + s.motd;
                    } else {
                        text += "● OFFLINE / NO STATUS RESPONSE\n" + s.error;
                    }
                    card.setText(text);
                }
                updated.setText("آخر تحديث: " + java.text.DateFormat.getTimeInstance().format(new java.util.Date())
                        + "   •   التحديث التالي بعد 15 ثانية");
                handler.postDelayed(this::refresh, 15000);
            });
        });
    }

    private Status check(Target target) {
        Status status = new Status(target);
        long start = System.nanoTime();
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(target.host, target.port), 3000);
            socket.setSoTimeout(3000);
            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            ByteArrayOutputStream handshake = new ByteArrayOutputStream();
            writeVarInt(handshake, 0);       // Handshake packet ID
            writeVarInt(handshake, -1);      // Protocol version: status-only probe
            writeString(handshake, target.host);
            handshake.write((target.port >> 8) & 0xff);
            handshake.write(target.port & 0xff);
            writeVarInt(handshake, 1);       // Status state

            ByteArrayOutputStream payload = new ByteArrayOutputStream();
            writeVarInt(payload, handshake.size());
            payload.write(handshake.toByteArray());
            payload.write(1);                // Status request packet length
            payload.write(0);                // Status request packet ID
            out.write(payload.toByteArray());
            out.flush();

            int packetLength = readVarInt(in);
            if (packetLength <= 0 || packetLength > 1_048_576) throw new Exception("Invalid status packet");
            int packetId = readVarInt(in);
            if (packetId != 0) throw new Exception("Unexpected packet ID");
            int jsonLength = readVarInt(in);
            if (jsonLength < 0 || jsonLength > 1_048_576) throw new Exception("Invalid JSON length");
            byte[] jsonBytes = new byte[jsonLength];
            in.readFully(jsonBytes);

            JSONObject json = new JSONObject(new String(jsonBytes, StandardCharsets.UTF_8));
            JSONObject version = json.optJSONObject("version");
            JSONObject players = json.optJSONObject("players");
            status.version = version == null ? "غير معروف" : version.optString("name", "غير معروف");
            status.players = players == null ? "—" :
                    players.optInt("online", 0) + " / " + players.optInt("max", 0);
            Object desc = json.opt("description");
            status.motd = desc == null ? "—" : desc.toString().replaceAll("[{}\\[\\]\"]", "");
            if (status.motd.length() > 85) status.motd = status.motd.substring(0, 85) + "...";
            status.ping = Math.max(0, (System.nanoTime() - start) / 1_000_000L);
            status.online = true;
        } catch (Exception e) {
            status.error = e.getMessage() == null ? "Connection failed" : e.getMessage();
        }
        return status;
    }

    private static void writeVarInt(ByteArrayOutputStream out, int value) {
        while ((value & ~0x7F) != 0) {
            out.write((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.write(value);
    }

    private static int readVarInt(DataInputStream in) throws Exception {
        int value = 0, position = 0;
        while (position < 35) {
            int b = in.readUnsignedByte();
            value |= (b & 0x7F) << position;
            if ((b & 0x80) == 0) return value;
            position += 7;
        }
        throw new Exception("VarInt too long");
    }

    private static void writeString(ByteArrayOutputStream out, String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        writeVarInt(out, bytes.length);
        out.write(bytes, 0, bytes.length);
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        stopped = true;
        handler.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }

    private static class Target {
        final String host; final int port;
        Target(String h, int p) { host = h; port = p; }
    }
    private static class Status {
        final Target target;
        boolean online = false;
        long ping = -1;
        String version = "—", players = "—", motd = "—", error = "No response";
        Status(Target t) { target = t; }
    }
}
